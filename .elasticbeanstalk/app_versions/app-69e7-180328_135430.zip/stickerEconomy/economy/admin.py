from django.contrib import admin
from .models import Sticker, Room
# Register your models here.
admin.site.register(Sticker)
admin.site.register(Room)