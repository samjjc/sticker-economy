from django.apps import AppConfig


class EconomyConfig(AppConfig):
    name = 'economy'
